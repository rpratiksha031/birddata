from .loader import load_bird
